<?php
/*$con = mysqli_connect("localhost", "root", "", "sports")or die($mysqli_error($con));
session_start();*/
?>
<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        
        <link href="index.css" rel="stylesheet" type="text/css"> 
        <title>Confirm Form</title>
        <style>
            label{width:180px;display:inline-block;text-align:right;vertical-align:top;color:white; }
            textarea{width:360px;height:50px}
        </style>

   <script type="text/javascript">
                 
		function validateForm() {
    var x = document.forms["myForm"]["name"].value;

    if (x == "") {
        alert("Name must be filled out");
        return false;
    }



}
	function ValidPage()
{
	var y = prompt("The info will be lost. do you wish to continue? yes or no");
	if(y=="yes")
	{
		
		window.location="http://localhost/web/confirm_form.php";
return true;
}
else
{
	return false;
}
}


</script> 
</head>
<body style="background-color:teal; ">
<?php 
        include("header.php");
        if (!isset($_SESSION['user_id'])) {
        header('location: IINDEX.php');
        }
        else{
		$cust_id=$_SESSION['user_id'];
		$query = "SELECT * from customer where id = '$cust_id'";
		$result = mysqli_query($con, $query)or die($mysqli_error($con));
		$row = mysqli_fetch_array($result);
            ?>
        <br><br><br>
        <div class="container-fluid" id="content">
            <div class="row">
                <div class="col-lg-4 col-lg-offset-4" id="settings-container">
			<form name="myForm" action="confirm.php" onsubmit="return validateForm()" method="post">
				<fieldset>
					<legend style="color: white;">Please update the delivery address:</legend><br>
					<div class="form-group">
						<label> Full Name:</label>
						<input type="text" value=<?php echo $row['name'];?> name="name"><br><br>
					</div>
					<div class="form-group">
						<label>  Phone:</label>
						<input type="number" value=<?php echo $row['mobile'] ;?> name="phone"><br><br>
					</div>
					<div class="form-group">
						<label>  Address:</label>
						<input type="text" value= <?php echo $row['address'];?> name="address"><br><br>
					</div>
					<div class="form-group">
						<label>  Landmark:</label>
						<input type="text" name="landmark"><br><br>
					<div>
					<br>
				</fieldset>
					<br>
					<div class="form-group">
						<label style="margin-left: 90px; color: white;">Mode of Payment: COD</label>
							
					<div>
					<br>
				<input style="margin-left: 150px;" type="submit" name="Deliver to this address" alert="Your order has been successfully placed" >
				<input type="button" value="Reset" onclick="ValidPage();">
			</form>
		</div>
            </div>
        </div>
        <?php 
        }
        include("footer.php"); ?>
    </body>
</html>
