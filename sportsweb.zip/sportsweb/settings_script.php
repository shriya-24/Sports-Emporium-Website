<?php

// This page updates the user password
$con = mysqli_connect("localhost", "root", "", "sports")or die($mysqli_error($con));
session_start();
if (!isset($_SESSION['email'])) {
    header('location: IINDEX.php');
}
$new_name=$_POST['name'];
$new_phone=$_POST['phone'];
$new_address=$_POST['address'];


$old_pass = $_POST['old_password'];
$old_pass = mysqli_real_escape_string($con, $old_pass);
$old_pass = md5($old_pass);


$new_pass = $_POST['password'];
$new_pass = mysqli_real_escape_string($con, $new_pass);
$new_pass = md5($new_pass);

$new_pass1 = $_POST['password1'];
$new_pass1 = mysqli_real_escape_string($con, $new_pass1);
$new_pass1 = md5($new_pass1);

$email=$_SESSION['email'];
$query = "SELECT * FROM customer WHERE email_id ='$email'";
$result = mysqli_query($con, $query)or die($mysqli_error($con));
$row = mysqli_fetch_array($result);
$orig_pass = $row['password'];




if ($new_pass != $new_pass1) {
    header('location: settings.php?error=The two passwords don\'t match');
} else {
    if ($old_pass == $orig_pass) {
	
      $query = "UPDATE  customer SET password = '$new_pass' WHERE email_id = '$email'";
       mysqli_query($con, $query) or die($mysqli_error($con));
	$query1 = "UPDATE  customer SET name = '$new_name'  , mobile = '$new_phone' , address ='$new_address' WHERE email_id = '$email'";
	mysqli_query($con, $query1) or die($mysqli_error($con));
	//echo "updated";
        //header('location: settings.php?error=Updated');
         echo"<script type='text/javascript'>alert('Profile Updated');</script>";
         echo "<script language='javascript' type='text/javascript'> location.href='IINDEX.php' </script>";
    } else

       header('location: settings.php?error=Wrong Old Password');

}
?>
