<?php
$con = mysqli_connect("localhost", "root", "", "sports");
if(isset($_SESSION['user_id'])||isset($_SESSION['user']))
{
    echo "<script language='javascript' type='text/javascript'> location.href='IINDEX.php' </script>";
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

</head>
<body style="background-color: teal;">
<?php 
        include("header.php");
        ?>
    <br><br>
    <div style="margin-left: 400px;"class="container-fluid decor_bg" id="login-panel">
                <div class="row">
                    <div class="col-md-6" style="margin-left: 25px;">
                        <div class="panel panel-success" >
                            <div class="panel-heading">
                                <h4>LOGIN</h4>
                            </div>
                            <div class="panel-body">
                                <p style="margin-left: 0px;">Login to make a purchase<p>
                                <form  method="POST">
                                    <div class="form-group">
                                        <input type="text" class="form-control"  placeholder="Username" name="username">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" placeholder="Password" name="password">
                                    </div>
                                    <button type="submit" name="submit" class="btn btn-info">Login</button>&nbsp;&nbsp;
                                    <button type="reset" name="reset" class="btn btn-info">Reset</button><br>
                                    
                                </form><br/>
                            </div>
                            <div class="panel-footer"><p>Don't have an account? <a href="signup.php">Register</a></p></div>
                        </div>
                    </div>
                </div>
            </div>
<?php
if (isset($_POST['submit']))
	{	  
/*include("config.php");*/

/*mysqli_select_db("sports", $con);*/
session_start();

$username=$_POST['username'];
$password=$_POST['password'];

$_SESSION['user']=$username;
 
$query = mysqli_query($con,"SELECT * FROM customer WHERE user_name='$username' and password=md5('$password')") or die(mysqli_error());
                        if (mysqli_num_rows($query)!= 0)
{

    $row = mysqli_fetch_array($query);
    $_SESSION['user_id']= $row['id'];
    $_SESSION['email']= $row['email_id'];
    
    
    echo "<script language='javascript' type='text/javascript'> location.href='IINDEX.php' </script>";
    //echo $row['id'];
    
 
}
else
{
echo "<script type='text/javascript'>alert('User Name Or Password Invalid!')</script>";
}

}

?>
    <br><br>
<?php 
        include("footer.php");
        ?>								
</body>
</html>
