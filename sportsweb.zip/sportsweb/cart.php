<!DOCTYPE html>
<html>
    <head>
        <title>Football Kit</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="text/javascript"> 
        
$(function(){
  $("#header").load("header.php"); 
  $("#footer").load("footer.php"); 
});
    </script>
    </head>
<?php
$con = mysqli_connect("localhost", "root", "", "sports")or die($mysqli_error($con));
session_start();
?>
<style>
.image{width:200px;height:200px;}
</style>
<html>
<head>
</head>
<body style="background-color: teal; ">
    <div id="header"></div><br><br>
<h3 style=" margin-left: 330px; color:white;">Cart Details</h3>  
<br><br>
                <div class="table-responsive">  
                    <table border="1" style="margin-left: 330px; color: white;">  
                        <tr bgcolor="#E6E6FA" style="color:black; text-align:center;">
				<th>Image</th>  
                               <th>Item Name</th>  
                               <th>Quantity</th>  
                               <th>Price</th>  
                               <th>Total</th>  
				<th>Action</th> 
                          </tr>  
			<?php
                        $total=0;
			$id=$_SESSION['user_id'];
			$select_query = "SELECT  * FROM cart where cust_id='$id' ";
			$select_query_result = mysqli_query($con, $select_query) or die(mysqli_error($con));
			while ($row = mysqli_fetch_array($select_query_result)) { ?>
                          <tr style="text-align:center;">  
                               <td><img class="image" src="<?php echo $row['image']; ?>"></td> 
				<td>&nbsp;<?php echo $row['brand']." ".$row['name']; ?>&nbsp;</td>  
                               <td>&nbsp;<?php echo $row['quantity']; ?>&nbsp;</td>  
                               <td>&nbsp;$ <?php echo $row['price']; ?>&nbsp;</td> 
				<td>&nbsp;$ <?php echo number_format($row['quantity'] * $row['price'], 2); ?>&nbsp;</td> 
				<form  method="POST">
				<input type="hidden" name="cartid" value="<?php echo $row["id"]; ?>" />
                                <td> &nbsp;&nbsp;&nbsp;<button type="submit" name="remove" style="color:black;">Remove</button>&nbsp;&nbsp;&nbsp;<br><br>
				&nbsp;&nbsp;&nbsp;<button type="submit" name="decrease" style="color:black;">Decrease</button>&nbsp;&nbsp;&nbsp;
				</td>
				</form>
                                 
			</tr>

		<?php
			$total = $total + ($row['quantity'] * $row['price']);
			}
		?>
			<tr>  
                               <td colspan="5" align="right">Total</td>  
                               <td align="right">$ <?php echo number_format($total, 2); ?></td>  
                               <td></td>  
                          </tr>  
			</table>
		</div>
		

<?php
if (isset($_POST['remove']))
{

$cart_id=$_POST['cartid'];
$query1="SELECT * FROM cart where id= '$cart_id'";
$query1_result=mysqli_query($con, $query1) or die(mysqli_error($con));
$row1 = mysqli_fetch_array($query1_result);

$name=$row1['name'];
$brand=$row1['brand'];
$quantity=$row1['quantity'];

$query2="SELECT * FROM football WHERE name='$name' and brand='$brand' ";
$query2_result=mysqli_query($con, $query2) or die(mysqli_error($con));
$row2 = mysqli_fetch_array($query2_result);
$prod_id=$row2['id'];

$delete_query= "delete from cart where id='$cart_id'";
$delete_result = mysqli_query($con, $delete_query) or die(mysqli_error($con));

$update1="update football set stock=stock+'$quantity' where id='$prod_id'";
$update1_result = mysqli_query($con, $update1) or die(mysqli_error($con));

echo "<script language='javascript' type='text/javascript'> location.href='cart.php' </script>";
}


if (isset($_POST['decrease']))
{
$cart_id=$_POST['cartid'];
$query1="SELECT * FROM cart where id= '$cart_id'";
$query1_result=mysqli_query($con, $query1) or die(mysqli_error($con));
$row1 = mysqli_fetch_array($query1_result);

$name=$row1['name'];
$brand=$row1['brand'];
$quantity=$row1['quantity'];

$query2="SELECT * FROM football WHERE name='$name' and brand='$brand' ";
$query2_result=mysqli_query($con, $query2) or die(mysqli_error($con));
$row2 = mysqli_fetch_array($query2_result);
$prod_id=$row2['id'];

$delete_query= "UPDATE cart set quantity=quantity-1 where id='$cart_id'";
$delete_result = mysqli_query($con, $delete_query) or die(mysqli_error($con));

$update1="update football set stock=stock+1 where id='$prod_id'";
$update1_result = mysqli_query($con, $update1) or die(mysqli_error($con));
echo "<script language='javascript' type='text/javascript'> location.href='cart.php' </script>";
}
?>
<br><br>
<form action="confirm_form.php">
<input style="margin-left: 610px;" type="submit" name="confirm_form" value="Confirm Address"/>
</form>
<br>
<form action="IINDEX.php">
<input style="margin-left: 600px;" type="submit" name="home" value="Continue Shopping"/>
</form>

<div id="footer"></div>
</body>
</html>
