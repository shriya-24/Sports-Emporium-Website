<?php
$con = mysqli_connect("localhost", "root", "", "sports")or die($mysqli_error($con));
$val=$_POST['rate'];
$id=$_POST['rid'];
        //echo $id;

$select_query1 = "SELECT  * FROM football WHERE id='$id'";
$select_query1_result = mysqli_query($con, $select_query1) or die(mysqli_error($con));
$result = mysqli_fetch_array($select_query1_result);

$name= $result['name'];

$rate_query = "insert into ratings (prod_name,rvalue) values ('$name','$val')";
$rate_query_result = mysqli_query($con, $rate_query) or die(mysqli_error($con));

echo "<script language='javascript' type='text/javascript'> location.href='football_kit.php' </script>";
?>
