
<?php
$conn = mysqli_connect("localhost", "root", "", "sports")or die($mysqli_error($conn));
$a = mysqli_query($conn, "SELECT * FROM football WHERE id=15") or die(mysqli_error());
$row1 = mysqli_fetch_array($a);
$b = mysqli_query($conn, "SELECT * FROM cricket WHERE id=18") or die(mysqli_error());
$row2 = mysqli_fetch_array($b);
$c = mysqli_query($conn, "SELECT * FROM kids WHERE id=16") or die(mysqli_error());
$row3 = mysqli_fetch_array($c);
$d = mysqli_query($conn, "SELECT * FROM fitness WHERE id=56") or die(mysqli_error());
$row4 = mysqli_fetch_array($d);

?>
<html>
<head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="mystyle.css">
        <script type="text/javascript"> 
         function equalHeight(group) {    
    tallest = 0;    
    group.each(function() {       
        thisHeight = $(this).height();       
        if(thisHeight > tallest) {          
            tallest = thisHeight;       
        }    
    });    
    group.each(function() { $(this).height(tallest); });
} 

$(document).ready(function() {   
    equalHeight($(".thumbnail")); 
});

    </script>

<body>
    <h1 style="color: white; margin-left:102px; ">Featured Products</h1>
<div class="container">
        <div class="row text-center"> 
<div class="col-md-3 col-sm-6">   
    <a href="football_kit.php" ><div class="thumbnail">
                            <img src="<?php echo $row1['image'];?>" alt="Adidas Football" style="border-width: 10px; width: 200px; height:200px ">
                            <div class="caption">
                                <h3><?php echo $row1['brand']." ".$row1['name'];?></h3>
                                <p>Price: Rs.<?php echo $row1['newprice'];?> <del><?php echo $row1['oldprice'];?></del></p>
                            </div>
                        </div>
                    </a>
            </div>

<div class="col-md-3 col-sm-6">   
    <a href="cricket_kit.php" ><div class="thumbnail">
                            <img src="<?php echo $row2['image'];?>" alt="Adidas Football" style="border-width: 10px; width: 200px; height:200px ">
                            <div class="caption">
                                <h3><?php echo $row2['brand']." ".$row2['name'];?></h3>
                                <p>Price: Rs.<?php echo $row2['newprice'];?> <del><?php echo $row2['oldprice'];?></del></p>
                            </div>
                        </div>
                    </a>
            </div>

<div class="col-md-3 col-sm-6">   
    <a href="kids_cycles.php" ><div class="thumbnail">
                            <img src="<?php echo $row3['image'];?>" alt="Adidas Football" style="border-width: 10px; width: 200px; height:200px ">
                            <div class="caption">
                                <h3><?php echo $row3['brand']." ".$row3['name'];?></h3>
                                <p>Price: Rs.<?php echo $row3['newprice'];?> <del><?php echo $row3['oldprice'];?></del></p>
                            </div>
                        </div>
                    </a>
            </div>


<div class="col-md-3 col-sm-6">   
    <a href="gym_equipments.php" ><div class="thumbnail">
                            <img src="<?php echo $row4['image'];?>" alt="Adidas Football" style="border-width: 10px; width: 200px; height:200px ">
                            <div class="caption">
                                <h3><?php echo $row4['brand']." ".$row4['name'];?></h3>
                                <p>Price: Rs.<?php echo $row4['newprice'];?> <del><?php echo $row4['oldprice'];?></del></p>
                            </div>
                        </div>
                    </a>
            </div>
</div>
</div>
</body>
</html>
