<?php
$con = mysqli_connect("localhost", "root", "", "sports")or die($mysqli_error($con));
session_start();
?>
<!DOCTYPE HTML>
<head>
    <title>Sports Emporium</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="google-site-verification" content="" />
    <meta name="keywords" content="" />
    <meta name="description" content="">
    <link href="stylee.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
   
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <script src="script.js"></script>
    
</head>

<body> 
    <header>

            <div class="row">
                <div class="col-md-4">
                    <div class="logo">
                        <a href="IINDEX.php"><img style="margin-left: -10px; width:350px; margin-top: 10px;" src="img/logo.png"/></a>
                    </div>
                    
                </div>
                <div class="col-md-4" id="search" style='margin-top:30px;'>
                    <form action="search.php" method="get">
                    <input type="text" name="q" dir="ltr" placeholder="Search">
                    <input type="submit" value=">>">
                    </form> 
                </div>
                <?php
               // $id=$_SESSION['user_id'];
                if (isset($_SESSION['email'])||isset($_SESSION['user'])) 
                {
                    if($_SESSION['user_id']==1000)
                    {
                ?>
                <div class="col-md-2" id='cssmenu' style='margin-top:5px; margin-left: 70px;'>
                <ul><li class="active has-sub"><a href="IINDEX.php"><span>Welcome ADMIN</span></a>
                    <ul>
                        <li class="has-sub"><a href="cart.php"><span>My Cart</span></a></li>
                        <li class="has-sub"><a href="order_summary.php"><span>Order Summary</span></a></li>
                        <li class="has-sub"><a href="settings.php"><span>Edit Profile</span></a></li>
                        <li class="has-sub"><a href="logout.php"><span>Logout</span></a></li>
                    </ul>
                    </li>
                    </ul>
                </div>
                
                <?php
                    }
                    else
                    {
                        ?>
                    
                        <div class="col-md-2" id='cssmenu' style='margin-top:5px;'>
                <ul><li class="active has-sub"><a href="IINDEX.php"><span>Welcome <?php echo $_SESSION['user'] ?></span></a>
                    <ul>
                        <li class="has-sub"><a href="cart.php"><span>My Cart</span></a></li>
                        <li class="has-sub"><a href="order_summary.php"><span>Order Summary</span></a></li>
                        <li class="has-sub"><a href="settings.php"><span>Edit Profile</span></a></li>
                        <li class="has-sub"><a href="logout.php"><span>Logout</span></a></li>
                    </ul>
                    </li>
                    </ul>
                </div>
                 <?php
                    }
                   
                }
                
                else
                {
                ?>
                <div class="col-md-4">
                    <span style="color:white; margin-left: 70px; margin-top: 30px;" class="glyphicon glyphicon-user"></span><a style="color: white;" href="login.php">&nbsp;Login&nbsp;&nbsp;&nbsp;&nbsp;</a>
                    <span style="color:white; margin-top: 30px;" class="glyphicon glyphicon-log-in"></span><a style="color: white;" href="signup.php">&nbsp;Sign Up&nbsp;</a>
                </div>
                <?php
                }
                ?>
            </div>
    </header>
    <br><br>
        <div id='cssmenu' style="width:1366px;">
            
            <ul>
                <li class="active has-sub"><a href="#"><span>Football</span></a>
                    <ul>
                        <li class="has-sub"><a href="football_kit.php"><span>Kit</span></a></li>
                        <li class="has-sub"><a href="football_apparel.php"><span>Apparel</span></a></li>
                        <li class="has-sub"><a href="football_studs.php"><span>Studs</span></a>
                    </ul>
                </li>
                <li class="active has-sub"><a href="#"><span>Badminton</span></a>
                    <ul>
                        <li class="has-sub"><a href="badminton_kit.php"><span>Kit</span></a>
                        <li class="has-sub"><a href="badminton_apparel.php"><span>Apparel</span></a>  
                        <li class="has-sub"><a href="badminton_shoes.php"><span>Shoes</span></a>
                    </ul>
                </li>
                <li class="active has-sub"><a href="#"><span>Fitness</span></a>
                    <ul>
                        <li class="has-sub"><a href="gym_equipments.php"><span>Gym Equipments</span></a></li>
                        <li class="has-sub"><a href="gym_yoga_equipments.php"><span>Yoga Equiments</span></a></li>
                        <li class="has-sub"><a href="gym_cardio_equipments.php"><span>Cardio Equipments</span></a></li>
                        <li class="has-sub"><a href="gym_fitness_apparel.php"><span>Fitness Sports Wear</span></a></li>
                        <li class="has-sub"><a href="gym_shoes.php"><span>Sports Shoes</span></a></li>
                        </ul>
                </li>
                <li class="active has-sub"><a href="#"><span>Cricket</span></a>
                    <ul>
                        <li class="has-sub"><a href="cricket_kit.php"><span>Kit</span></a></li>
                        <li class="has-sub"><a href="cricket_bandb.php"><span>Bat+Ball</span></a></li>
                        <li class="has-sub"><a href="cricket_shoes.php"><span>Shoes</span></a></li>
                    </ul>
                </li>
                <li class="active has-sub"><a href='#'><span>Kids</span></a>
                    <ul>
                        <li class="has-sub"><a href="kids_apparel.php"><span>Apparel</span></a></li>
                        <li class="has-sub"><a href="kids_shoes.php"><span>Shoes</span></a></li>
                        <li class="has-sub"><a href="kids_cycles.php"><span>Cycles</span></a></li>
                        <li class="has-sub"><a href="kids_skates.php"><span>Skates</span></a></li>
                    </ul>
                </li>
            </ul>
            
        </div>
    <br>
</body>
</html>

