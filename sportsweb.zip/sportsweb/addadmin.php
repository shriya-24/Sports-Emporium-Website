<?php
$con = mysqli_connect("localhost", "root", "", "sports")or die($mysqli_error($con));



    $type="kit";
    $brand=$_POST['brand'];
    $name=$_POST['name'];
    $stock=$_POST['stock'];
    $oldprice=$_POST['oldprice'];
    $newprice=$_POST['newprice'];
    $image=$_POST['image'];
    $description=$_POST['description'];
    
    $insert_query="insert into football(type,brand,name,stock,oldprice,newprice,image,description) values('$type','$brand','$name','$stock','$oldprice','$newprice','$image','$description')";
    $insert_submit = mysqli_query($con, $insert_query) or die(mysqli_error($con));
    
 
    echo "<script language='javascript' type='text/javascript'> location.href='football_kit.php' </script>";
    


?>
