<?php
$con = mysqli_connect("localhost", "root", "", "sports")or die($mysqli_error($con));
?>
<html>
<head>
<title>Signup Form</title>
<style>
/*fieldset{width:65%}*/
/*input{text-align:left;}*/
form{width:65%;margin-left:170px;margin-top:55px}
label{width:180px;display:inline-block;text-align:right;vertical-align:top}
textarea{width:360px;height:50px}
.radio{display:inline-block}
</style>
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>    
<script type="text/javascript">
                 function Captcha(){
                     var alpha = new Array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','1','2','3','4','5','6','7','8','9','0');
                     var i;
                     for (i=0;i<6;i++){
                       var a = alpha[Math.floor(Math.random() * alpha.length)];
                       var b = alpha[Math.floor(Math.random() * alpha.length)];
                       var c = alpha[Math.floor(Math.random() * alpha.length)];
                       var d = alpha[Math.floor(Math.random() * alpha.length)];
                       var e = alpha[Math.floor(Math.random() * alpha.length)];
                       var f = alpha[Math.floor(Math.random() * alpha.length)];
                       var g = alpha[Math.floor(Math.random() * alpha.length)];
                      }
                    var code = a + b + c  + d  + e + f + g;
                    document.getElementById("mainCaptcha").value = code
                  }
                  function ValidCaptcha(){
                      var string1 = removeSpaces(document.getElementById('mainCaptcha').value);
                      var string2 = removeSpaces(document.getElementById('txtInput').value);
                      if (string1 == string2)
                   {
		alert("Captcha Valid");
		return true;
		}
                      else{        
			alert("Captcha Invalid");
                        return false;
                      }
                  }
                  function removeSpaces(string){
                    return string.split(' ').join('');
                  }
		function validateForm() {
    var x = document.forms["myForm"]["name"].value;
var z=document.forms["myForm"]["password"].value.length;
var y=document.forms["myForm"]["phone"].value.length;

    if (x == "") {
        alert("Name must be filled out");
        return false;
    }
else if(z<6)

{
alert("Password too short!!");
return false;
}
else if(y<10)

{
alert("Phone Number is not of 10 digits");
return false;
}


}
	function ValidPage()
{
	var y = prompt("The info will be lost. Do you wish to continue? yes or no");
	if(y=="yes")
	{
		
		window.location.href="http://localhost/sportsweb/signup.php";
return true;
}
else
{
	return false;
}
}
$(document).ready(function(){

    $("#pwinput").focus();

    $("#pwcheck").click(function(){
        if ($("#pwcheck").is(":checked"))
        {
            $("#pwinput").clone()
            .attr("type", "text").insertAfter("#pwinput")
            .prev().remove();
        }
        else
        {
            $("#pwinput").clone()
            .attr("type","password").insertAfter("#pwinput")
            .prev().remove();
        }
    });
});

             </script> 
</head>
<body style="background-color: teal; color: white;" onload="Captcha();">
    <h2 style="text-align: center; ">Signup Form</h2>
 <form name="myForm" action="signup_submit.php"
 onsubmit="return validateForm()" method="POST">
<fieldset>
<legend>Personal Information:</legend><br>
<label>  First Name:</label>
<input type="text" placeholder="Your Name" name="name"><br><br>

<!--<label>  Last Name:</label>
<input type="text" placeholder="Your Last Name" name="last name"><br><br>

<label>Gender:</label>
<input type="radio" name="gender" >Female
<input type="radio" name="gender" >Male<br><br>-->


<label>  Phone:</label>
<input type="number" name="phone" ><br><br>

<label>  Address:*</label>
<textarea name="address" required></textarea><br><br>

<label>  Country:</label>
<select name="country">
<option value="India" selected>India</option>
<option value="China" >China</option>
<option value="Sri Lanka" >Sri Lanka</option>
<option value="Bangladesh" >Bangladesh</option>
<option value="Australia" >Australia</option>
</select>
<br>
</fieldset>
<br>

<fieldset>
<legend>Login Information:</legend><br>
<label>  Email Id:*</label>
<input type="emailid" name="email" required><br><br>
<label>  Username:*</label>
<input type="text" name="username" required><br><br>
<label>  Password:</label>
<input type="password" id="pwinput"  name="password">
<input type="checkbox" id="pwcheck" />Show Password<br>
</fieldset>
<br>
<fieldset><br>
<label>Text Captcha:</label>
<input type="text" id="mainCaptcha"/>
<input type="button" id="refresh" value="Refresh" onclick="Captcha();" /><br><br>
<label>Enter Captcha:</label>
<input type="text" id="txtInput"/>    
<br>
</fieldset><br>
<input type="submit"  onclick="return ValidCaptcha()">
<input type="button" value="Reset" onclick="return ValidPage()">

</form>