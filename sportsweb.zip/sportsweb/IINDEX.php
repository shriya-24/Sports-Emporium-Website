<?php
$con = mysqli_connect("localhost", "root", "", "sports")or die($mysqli_error($con));
session_start();

?>
<!DOCTYPE HTML>
<head>
    <title>Sports Emporium</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="google-site-verification" content="" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="stylee.css">
    <link rel="stylesheet" href="mystyle.css">
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <script src="script.js"></script>
    
    <style>
        
      
        footer{display:inline-block; background-color:#FFFFE0; color:#333; width:100%; height:150px; margin-top:260px;} 
        footer .p{display:inline-block; font-family:PT Sans;} 
        footer .a{margin-left:25px;}

        footer .logo{display:inline-block; height:45px; float:left; padding:15px;}
        footer .img{height:100%;}
    </style>
    
</head>

<body>
    <header>

            <div class="row">
                <div class="col-md-4">
                    <div class="logo">
                        <a href="IINDEX.php"><img style="margin-left: -10px; width:350px; margin-top: 10px;" src="img/logo.png"/></a>
                    </div>
                    
                </div>
                <div class="col-md-4" id="search" style='margin-top:30px;'>
                    <form action="search.php" method="get">
                    <input type="text" name="q" dir="ltr" placeholder="Search">
                    <input type="submit" value=">>">
                    </form> 
                </div>
                <?php
               // $id=$_SESSION['user_id'];
                if (isset($_SESSION['email'])||isset($_SESSION['user'])) 
                {
                    if($_SESSION['user_id']==1000)
                    {
                ?>
                <div class="col-md-2" id='cssmenu' style='margin-top:5px; margin-left: 70px;'>
                <ul><li class="active has-sub"><a href="IINDEX.php"><span>Welcome ADMIN</span></a>
                    <ul>
                        <li class="has-sub"><a href="cart.php"><span>My Cart</span></a></li>
                        <li class="has-sub"><a href="order_summary.php"><span>Order Summary</span></a></li>
                        <li class="has-sub"><a href="settings.php"><span>Edit Profile</span></a></li>
                        <li class="has-sub"><a href="logout.php"><span>Logout</span></a></li>
                    </ul>
                    </li>
                    </ul>
                </div>
                
                <?php
                    }
                    else
                    {
                        ?>
                    
                        <div class="col-md-2" id='cssmenu' style='margin-top:5px;'>
                <ul><li class="active has-sub"><a href="IINDEX.php"><span>Welcome <?php echo $_SESSION['user'] ?></span></a>
                    <ul>
                        <li class="has-sub"><a href="cart.php"><span>My Cart</span></a></li>
                        <li class="has-sub"><a href="order_summary.php"><span>Order Summary</span></a></li>
                        <li class="has-sub"><a href="settings.php"><span>Edit Profile</span></a></li>
                        <li class="has-sub"><a href="logout.php"><span>Logout</span></a></li>
                    </ul>
                    </li>
                    </ul>
                </div>
                 <?php
                    }
                   
                }
                
                else
                {
                ?>
                <div class="col-md-4">
                    <span style="color:white; margin-left: 70px; margin-top: 30px;" class="glyphicon glyphicon-user"></span><a style="color: white;" href="login.php">&nbsp;Login&nbsp;&nbsp;&nbsp;&nbsp;</a>
                    <span style="color:white; margin-top: 30px;" class="glyphicon glyphicon-log-in"></span><a style="color: white;" href="signup.php">&nbsp;Sign Up&nbsp;</a>
                </div>
                <?php
                }
                ?>
            </div>
        
    </header>
    <br>
    <div id='cssmenu' style="width:1366px;" >
            
            <ul>
                <li class="active has-sub"><a href="#"><span>Football</span></a>
                    <ul>
                        <li class="has-sub"><a href="football_kit.php"><span>Kit</span></a></li>
                        <li class="has-sub"><a href="football_apparel.php"><span>Apparel</span></a></li>
                        <li class="has-sub"><a href="football_studs.php"><span>Studs</span></a>
                    </ul>
                </li>
                <li class="active has-sub"><a href="#"><span>Badminton</span></a>
                    <ul>
                        <li class="has-sub"><a href="badminton_kit.php"><span>Kit</span></a>
                        <li class="has-sub"><a href="badminton_apparel.php"><span>Apparel</span></a>  
                        <li class="has-sub"><a href="badminton_shoes.php"><span>Shoes</span></a>
                    </ul>
                </li>
                <li class="active has-sub"><a href="#"><span>Fitness</span></a>
                    <ul>
                        <li class="has-sub"><a href="gym_equipments.php"><span>Gym Equipments</span></a></li>
                        <li class="has-sub"><a href="gym_yoga_equipments.php"><span>Yoga Equiments</span></a></li>
                        <li class="has-sub"><a href="gym_cardio_equipments.php"><span>Cardio Equipments</span></a></li>
                        <li class="has-sub"><a href="gym_fitness_apparel.php"><span>Fitness Sports Wear</span></a></li>
                        <li class="has-sub"><a href="gym_shoes.php"><span>Sports Shoes</span></a></li>
                        </ul>
                </li>
                <li class="active has-sub"><a href="#"><span>Cricket</span></a>
                    <ul>
                        <li class="has-sub"><a href="cricket_kit.php"><span>Kit</span></a></li>
                        <li class="has-sub"><a href="cricket_bandb.php"><span>Bat+Ball</span></a></li>
                        <li class="has-sub"><a href="cricket_shoes.php"><span>Shoes</span></a></li>
                    </ul>
                </li>
                <li class="active has-sub"><a href='#'><span>Kids</span></a>
                    <ul>
                        <li class="has-sub"><a href="kids_apparel.php"><span>Apparel</span></a></li>
                        <li class="has-sub"><a href="kids_shoes.php"><span>Shoes</span></a></li>
                        <li class="has-sub"><a href="kids_cycles.php"><span>Cycles</span></a></li>
                        <li class="has-sub"><a href="kids_skates.php"><span>Skates</span></a></li>
                    </ul>
                </li>
            </ul>
            
        </div>
    
    <div class="slider">
        <img class="slide" src="img/badminton.png">
        <img class="slide" src="https://png.pngtree.com/thumb_back/fh260/back_pic/04/21/36/73582ffd6891cf6.jpg">
        <img class="slide" src="https://www.discoverymundo.com/blog/wp-content/uploads/2016/07/sports-cancun.jpg">
        <img class="slide" src="https://reviewonline.co.za/wp-content/uploads/sites/68/2016/12/bigstock-Four-Sports-a-lot-of-balls-an-50626115.jpg">
        <img class="slide" src="img/tabletennis.jpg">
    </div>
    
    <br>
    <br>
    <br>
    <br>
    
    <script>
        var myIndex = 0;
        autoslide();
        function autoslide()
        {
            var i;
            var x = document.getElementsByClassName("slide");
            for (i = 0; i < x.length; i++)
            {
                x[i].style.display = "none";  
            }
            myIndex++;
        if (myIndex > x.length) {myIndex = 1}    
        x[myIndex-1].style.display = "block";  
        setTimeout(autoslide, 2000); // Change image every 2 seconds
        }
    </script>
    <br><br>
     <?php   include("featured.php"); ?>
    <footer>
        <div class="row">
            <div class="col-md-6">
                <center>
                    <p><b>SPORTS EMPORIUM</b></p>
                <a href="IINDEX.php">Home </a>
              <a href="terms.php">| Terms </a>
                <a href="about.php">| About </a>
                <a href="faq.php">| FAQ </a><br>
                <a href="facebook.com"><img src="img/fb.png"></a>
                <a href="twitter.com"><img src="img/tw.png"></a>
                </center>
            </div>
            <div class="col-md-3">
                <ul style="list-style-type:none">
                    <li><span class="glyphicon glyphicon-map-marker"></span> Vidyavihar, Mumbai-070</li>
                    <li><span class="glyphicon glyphicon-phone-alt"></span> +91 98 5645 3456</li>
                    <li><span class="glyphicon glyphicon-envelope"></span> mail@support_sportsemporium.com</li>
                </ul>
            </div>
   
    </div>
        <div class="row">
            <center><p><b>Copyright &copy;2017 Sports Emporium. All Rights Reserved</b></p></center>  
        </div>
    </footer>
</body>
</html>
