<!DOCTYPE HTML>
<head>
    <title>Sports Emporium</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="google-site-verification" content="" />
    <meta name="keywords" content="" />
    <meta name="description" content="" / >
    <link href="stylee.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <script src="script.js"></script>
    <style>
        footer{display:inline-block; background-color:#FFFFE0; color:#333; width:100%; height:150px; margin-top:260px;} 
        footer .p{display:inline-block; font-family:PT Sans;} 
        footer .a{margin-left:25px;}

        footer .logo{display:inline-block; height:45px; float:left; padding:15px;}
        footer .img{height:100%;}
    </style>
    
</head>

<body>
<footer>
        <div class="row">
            <div class="col-md-6">
                <center>
                    <p><b>SPORTS EMPORIUM</b></p>
                <a href="IINDEX.php">Home </a>
              <a href="terms.php">| Terms </a>
                <a href="about.php">| About </a>
                <a href="faq.php">| FAQ </a><br>
                <a href="facebook.com"><img src="img/fb.png"></a>
                <a href="twitter.com"><img src="img/tw.png"></a>
                </center>
            </div>
            <div class="col-md-3">
                <ul style="list-style-type:none">
                    <li><span class="glyphicon glyphicon-map-marker"></span> Vidyavihar, Mumbai-070</li>
                    <li><span class="glyphicon glyphicon-phone-alt"></span> +91 98 5645 3456</li>
                    <li><span class="glyphicon glyphicon-envelope"></span> mail@support_sportsemporium.com</li>
                </ul>
            </div>

    </div>
        <div class="row">
            <center><p><b>Copyright &copy;2017 Sports Emporium. All Rights Reserved</b></p></center>  
        </div>
    </footer>
</body>
</html>


