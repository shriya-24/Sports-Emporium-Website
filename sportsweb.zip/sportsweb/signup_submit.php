<?php
$con = mysqli_connect("localhost", "root", "", "sports")or die($mysqli_error($con));

$name =  $_POST['name'];
$address =  $_POST['address'];
$country =  $_POST['country'];

$email = $_POST['email'];

$password = $_POST['password'];

$username = $_POST['username'];
$phone = $_POST['phone'];

$select_query = "SELECT  id FROM customer where email_id= '$email'";
$select_result = mysqli_query($con, $select_query) or die(mysqli_error($con));
if(mysqli_num_rows($select_result)>0)
{
    echo "User already Exists";
    
   
}
 else 
{  
     $user_registration_query = "insert into customer (name,address,country,email_id,user_name,password,mobile) values ('$name','$address','$country','$email','$username',md5('$password'),'$phone')";
     mysqli_query($con, $user_registration_query) or die(mysqli_error($con));
     
     //echo "user added";
     session_start();

     $user_id = mysqli_insert_id($con);
     $_SESSION['email'] = $email;
     $_SESSION['user_id'] = $user_id;
     $_SESSION['user'] = $username;
     header('location: IINDEX.php');
     
}

