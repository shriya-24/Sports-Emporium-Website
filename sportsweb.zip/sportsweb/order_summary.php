<?php 
include("header.php");
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sports";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$id2=$_SESSION['user_id'];

$sql = "SELECT * FROM order_details where cid=$id2";
$result = $conn->query($sql);


$xml=new DOMDocument("1.0");

$xml->formatOutput=True;
$order=$xml->createElement("order");
$xml->appendChild($order);
$total=0;
while($row=mysqli_fetch_array($result))
{
		$item=$xml->createElement("item");
		$order->appendChild($item);
	 
		
                $pro_name=$xml->createElement("pro_name",$row['prod_name']);
		$item->appendChild($pro_name);

		$pro_brand=$xml->createElement("pro_price",$row['prod_price']);
		$item->appendChild($pro_brand);

		$quantity=$xml->createElement("quantity",$row['quantity']);
		$item->appendChild($quantity);
                
                $date=$xml->createElement("date",$row['order_date']);
		$item->appendChild($date);
                
                $address=$xml->createElement("address",$row['Address']);
		$item->appendChild($address);
                
		$total_price=$xml->createElement("total_price",$row['price']);
		$item->appendChild($total_price);

		

		$total = $total + ($row['quantity'] * $row['price']);
		
}	
//echo "<xmp>".$xml->saveXML()."</xmp>";
//echo $total;
$t=$xml->createElement("total",number_format($total,2));
$order->appendChild($t);

$xml->save("order_table.xml");
function loadFile($xml, $xsl)
{
$xmlDoc = new DOMDocument();
$xmlDoc->load($xml);

$xslDoc = new DOMDocument();
$xslDoc->load($xsl);

$proc = new XSLTProcessor();
$proc->importStyleSheet($xslDoc);
echo $proc->transformToXML($xmlDoc);
}
loadFile("order_table.xml", "order_xsl.xsl");
?>
<br><br>

<form action="IINDEX.php">
<input style="margin-left: 600px;" type="submit" name="home" value="Continue Shopping"/>
</form>

<?php
include("footer.php");
?>

