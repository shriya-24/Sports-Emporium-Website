<html>
<head>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        
        <link href="index.css" rel="stylesheet" type="text/css"> 
        <title>Add Product Form</title>
        <style>
            
            label{width:180px;display:inline-block;text-align:right;vertical-align:top;color:white; }
            textarea{width:360px;height:50px}
       
        </style>
   <script type="text/javascript">
</script>
</head>
<body style="background-color: teal;">
<?php

  $conn = mysqli_connect("localhost", "root", "", "sports")or die($mysqli_error($con));
   
    include("header.php");
    ?>
    <div class="container-fluid" id="content">
            <div class="row">
                <div class="col-lg-4 col-lg-offset-4" id="settings-container">
			<form method="POST" action="addadmin.php">
				<fieldset>
                                    <legend style="color: white;">Please provide the details of the product to be added</legend><br>
					<div class="form-group">
						<label>Brand:</label>
       						 <input type="text" name="brand" ><br><br>
					</div>
					<div class="form-group">
						<label>Name:</label>
        					<input type="text" name="name"><br><br>
					</div>
					<div class="form-group">
						<label>Stock:</label>
       						 <input type="text" name="stock"><br><br>
					</div>
					<div class="form-group">
						<label>Old Price:</label>
        					<input type="text" name="oldprice" ><br><br>
					</div>
					<div class="form-group">
						<label>New Price:</label>
      						  <input type="text" name="newprice"><br><br>
					</div>
					<div class="form-group">
						<label>Image:</label>
      						 <input type="text" name="image" placeholder="Image url"><br><br>
					</div>
					<div class="form-group">
						<label>Description:</label>
       						 <input type="text" name="description" placeholder="Description url"><br><br>
					</div>
					<br>
				</fieldset>
                            <input style="color: black; margin-left: 200px;" type="submit" name="Add" value="Add">
			</form>
		</div>
            </div>
        </div>
    <?php
    include("footer.php");
    ?>
<body>
</html>


    
