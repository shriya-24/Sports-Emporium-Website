<?php
$con = mysqli_connect("localhost", "root", "", "sports")or die($mysqli_error($con));

$id1=$_POST['id'];
$id2=$_POST['cid'];
$quantity1=$_POST['quantity'];
$res="SELECT * FROM football where id= '$id1'";
$res_result=mysqli_query($con, $res) or die(mysqli_error($con));

$row = mysqli_fetch_array($res_result);

$name = $row['name'];
$brand = $row['brand'];
$price = $row['newprice'];
$image=$row['image'];
//$output = ' <p>'.$name.'  ' . $brand . '  '.$price.'</p>';
//print("$output" );

  $update_query="UPDATE football set stock =stock-'$quantity1' where id='$id1'";
    $update_result=mysqli_query($con, $update_query) or die(mysqli_error($con));
    $select_query = "SELECT * FROM cart where brand= '$brand' AND name='$name' AND cust_id='$id2'";
    $select_result = mysqli_query($con, $select_query) or die(mysqli_error($con));

    if(mysqli_num_rows($select_result)>0)
    {
        echo"<script type='text/javascript'>alert('Item already exists. Quantity increemented');</script>";
	$row1 = mysqli_fetch_array($select_result);
	$id3=$row1['id'];
	$update_query1 = "UPDATE cart SET quantity=quantity+'$quantity1' where id='$id3'";
        $update_query_result = mysqli_query($con, $update_query1) or die(mysqli_error($con));
   
    }
    else{

    $cart_item_insertion_query = "INSERT  into cart(name,brand,price,quantity,cust_id,image) values ('$name','$brand','$price','$quantity1','$id2','$image')";
    $cart_item_insertion_submit = mysqli_query($con, $cart_item_insertion_query) or die(mysqli_error($con));
     echo"<script type='text/javascript'>alert('Item added');</script>";
    }

 echo "<script language='javascript' type='text/javascript'> location.href='cart.php' </script>";
?>
