<?php
$con = mysqli_connect("localhost", "root", "", "sports")or die($mysqli_error($con));
$select_query = "SELECT  * FROM cricket WHERE type='kit'";
$select_query_result = mysqli_query($con, $select_query) or die(mysqli_error($con));
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Cricket Kit</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="text/javascript"> 
    function equalHeight(group) {    
    tallest = 0;    
    group.each(function() {       
        thisHeight = $(this).height();       
        if(thisHeight > tallest) {          
            tallest = thisHeight;       
        }    
    });    
    group.each(function() { $(this).height(tallest); });
} 

$(document).ready(function() {   
    equalHeight($(".thumbnail")); 
});
$(function(){
  $("#header").load("header.php"); 
  $("#footer").load("footer.php"); 
});
</script>
    </head>
</head>
<body style="background-color: teal;">
    <div id="header"></div>
    <div class="container">
        <br><br>
       
        
        <div class="row text-center">
             <?php while ($row = mysqli_fetch_array($select_query_result)) { ?>
            <div class="col-md-3 col-sm-6">
                <a href="" ><div class="thumbnail">
                            <?php if($row['stock']!=0)
                          { ?>
                            <img src="<?php echo $row['image'];?>" alt="Image" style="border-width: 10px; width: 200px; height:200px ">
                          <?php }
                          else { ?>
                            <img src="<?php echo $row['image'];?>" alt="Image" style="filter:blur(5px);  border-width: 10px; width: 200px; height:200px ">
                            <div style="color: white; position: absolute; top: 25%; left: 50%; transform: translate(-50%, -50%);"><b>Out of Stock</b></div>
                          <?php }
                          ?>
                            <div class="caption">
                                <h3><?php echo $row['brand']." ".$row['name'];?></h3>
                                <p>Price: Rs.<?php echo $row['newprice'];?> <del><?php echo $row['oldprice'];?></del></p>
                            </div>
                        </div>
                    </a>
            </div>
          
        <?php } ?>
    </div>
</div>
<br>

<div id="footer"></div>	
</body>
</html>
