<?php
session_start();
if(session_destroy())
{
    /*echo "<script type='text/javascript'> alert('Successfully Logged out!!')</script>" ;
    
    header("Location: IINDEX.php"); */  
    
    echo '<script type="text/javascript">';
    echo 'alert("Successfully Logged out!!");';
    echo 'window.location.href="http://localhost/sportsweb/IINDEX.php";';
    echo '</script>';
}
else
{
    header("Location:login.php");
}
?>
