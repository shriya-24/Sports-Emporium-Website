<?php
$con = mysqli_connect("localhost", "root", "", "sports")or die($mysqli_error($con));
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Description 5</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="text/javascript"> 
       
$(function(){
  $("#header").load("header.php"); 
  $("#footer").load("footer.php"); 
});
 </script>
<style>
.image img{width:350px;height:350px; margin-left:75px; box-shadow: 10px 10px 5px #888888;}
</style>
</head>

<body style="background-color: teal; ">
<div id="header"></div>
<br>
<br>
<table cellpadding="0" cellspacing="0" border="0" style="margin-left:142px;width:1024px">
	<tr style="height: 600px;">
		<td style="width: 500px;">
			<br>
			<div class="image">
                            <img src="https://rukminim1.flixcart.com/image/704/704/ball/x/f/d/400-22-5-cr7-utd-white-2-cr7-utd-white-football-retail-world-original-imaerjavh8dgx5qn.jpeg?q=70">
			</div>
<br>
<br>
<?php
$con = mysqli_connect("localhost", "root", "", "sports")or die($mysqli_error($con));
//echo $_SESSION['user'];
$username=$_SESSION['user'];
$select_query = "SELECT * FROM customer WHERE user_name='$username'";
$select_query_result = mysqli_query($con, $select_query) or die(mysqli_error($con));
$row = mysqli_fetch_array($select_query_result);
//echo $row['id'];
//$output = ' <p>'.$cid.' </p>';
//print("$output" );
$id1=$_POST['id'];
$select_query1 = "SELECT  * FROM football WHERE id='$id1'";
$select_query1_result = mysqli_query($con, $select_query1) or die(mysqli_error($con));
$result = mysqli_fetch_array($select_query1_result);
//echo $result['name'];
?>
			<form method="post" action="add_to_cart.php">  
				<div class="button">      
   					 <p style="margin-left:45px;"><b> Available Stock: <?php echo $result['stock'];?> </b></p>	
    					<label style="margin-left:45px;" >Quantity:</label>
					<input type="number" name="quantity" id="quantity" max="<?php echo $result['stock'];?>" />	</p>
					<input type="hidden" name="id" value="<?php echo $id1 ;?>" /> 
					<input type="hidden" name="cid" value="<?php echo $row['id'];?>" /> 
        				<?php
      					if (isset($_SESSION['user_id']))
       					{
        				if($result['stock']!=0)
        				{
        				?>
       					 <input type="submit" class="btn btn-info btn-lg" name="add_to_cart" value="Add to Cart" style="margin-left:35px;" onclick="return AvailableStock()"/>  
       					 <?php
       					}
        				}
       					?>

				</div>  
			</form> 
		</td>

		<td>
			<h1 style="margin-top:-35px; color: white;"><?php echo $result['brand']." ".$result['name'];?></h1>
			<h2 style="color: white;">Price: Rs.<?php echo $result['newprice'];?> </h2><br>
                        <?php $name= $result['name'];
                          $select_query2 = "SELECT  * FROM ratings WHERE prod_name='$name'";
                          $select_query2_result = mysqli_query($con, $select_query2) or die(mysqli_error($con));
$count=0;
$total=0;
while($result2 = mysqli_fetch_array($select_query2_result))
{
    $count=$count+1;
    $total=$total+$result2['rvalue'];
}
$res=$total/$count;
?><h4 style="color:white"><?php echo $res;?>&nbsp;<span style="color:yellow;" class="glyphicon glyphicon-star"></span></h4>
                        
			<h3 style="color: wheat;">Description</h3>
			<p style="color: wheat;"> Spring Summer 2014 Collection

				For incredible power and speed, get the cool Brazuca Hard Ground Football from Adidas and make those spot-on 	shots with great control.

			High Abrasion Resistance

			Resistant to abrasion and damages, this football can be subjected to intense pressure.

			Thermoplastic Polyurethane (100%)
		
			Made from pure thermoplastic polyurethane to offer increased strength, this football helps in enhancing your performance.

			Rubber, Polyester and Cotton Construction

			The unique blend of rubber, polyester and cotton materials combine to provide an excellent feel.
	
			High Durability and Good Touch

			The perfect manufacturing materials used in its construction ensure high durability and a long life.
			</p>
                        <br>
                        <h4 style="color: wheat;">Rate the product:</h4>
                        
                        <form action="rating_submit.php" method="POST">
                            <p><input type="number" name="rate" id="quantity" max="5" min="1" placeholder="Max 5" /></p>
                            <p><input type="submit" class="btn btn-info btn-lg" name="rateb" value="Rate"/> 
                            <input type="hidden" name="rid" value="<?php echo $id1 ;?>" /> </p>
                        </form>
		</td>
	</tr>
</table>

 <br><br><br>
<div id="footer"></div>
</body>
</html>

