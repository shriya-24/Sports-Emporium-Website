
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Edit Profile</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            label{width:180px;display:inline-block;text-align:right;vertical-align:top;color:white; }
            textarea{width:360px;height:50px}
        </style>

        <script type="text/javascript"> 
        </script>
    </head>
    <body style="background-color: teal;">
        <?php 
        include("header.php");
        if (!isset($_SESSION['user_id'])) {
        header('location: IINDEX.php');
        }
        else{
		$cust_id=$_SESSION['user_id'];
		$query = "SELECT * from customer where id = '$cust_id'";
		$result = mysqli_query($con, $query)or die($mysqli_error($con));
		$row = mysqli_fetch_array($result);
            ?>
        <br><br><br>
        <div class="container-fluid" id="content">
            <div class="row">
                <div class="col-lg-4 col-lg-offset-4" id="settings-container">
                    
                    <form action="settings_script.php" method="POST">
			<fieldset>
                            <legend style="color: wheat;">Personal Information:</legend><br>
			<div class="form-group">
				<label>  Name:</label>
				<input type="text" value=<?php echo $row['name'];?> name="name"><br><br>
			</div>
			<div class="form-group">
				<label>  Phone:</label>
				<input type="number" value=<?php echo $row['mobile'] ;?> name="phone" ><br><br>
			</div>
			<div class="form-group">
				<label>  Address:</label>
				<input type="address" name="address" value= <?php echo $row['address'];?> required><br><br>
			</div>
			
			</fieldset>
			<br>

			<fieldset>
			<legend style="color: wheat;">Change Password:</legend><br>
                        <div class="form-group">
                            <input type="password" class="form-control" name="old_password"  placeholder="Old Password" required = "true">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="password" placeholder="New Password" required = "true">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="password1"  placeholder="Re-type New Password" required = "true">
                        </div>
                        <button style="margin-left:160px;" type="submit" class="btn btn-info">Change</button>
                        
                    </form>
                </div>
            </div>
        </div>
        <?php 
        }
        include("footer.php"); ?>
    </body>
</html>
