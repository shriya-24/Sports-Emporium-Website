<!DOCTYPE html>
<html>
    <head>
        <title>Order Confirmation</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
        
      
        footer{display:inline-block; background-color:#FFFFE0; color:#333; width:100%; height:150px; margin-top:260px;} 
        footer .p{display:inline-block; font-family:PT Sans;} 
        footer .a{margin-left:25px;}

        footer .logo{display:inline-block; height:45px; float:left; padding:15px;}
        footer .img{height:100%;}
    </style>
        <script type="text/javascript"> 
	$(function(){
  $("#header").load("header.php"); 
  $("#footer").load("footer.html"); 
});
    </script>
    </head>
<body style="background-color: teal;">
 <div id="header"></div>
 <h1 style="margin-left:580px; margin-top: 100px; color:wheat;">FAQ</h1>
<br>
<div style="color:white;">
<p>Do you create landing page for clients? 
Yes, we have the option to create landing pages which gives the opportunity for brands to showcase their product portfolio and value propositions.
</p>
<p>
What is premium inventory and which Ad formats are included? 
Premium inventory includes the top banner and the right hand side cards on our website. This inventory is visible to all our consumers visiting the site. Having your Ads displayed on premium property can help provide instant visibility to wide range of audience.
</p>
<p>
How does the pricing work? 
Currently we follow two pricing models; CPD and CPM. CPD translates to cost per day where the inventory slot is available for one day. CPM which is cost per thousand impressions allows brands to target exclusivity while advertise.
</p>
<p>
What is OSA (Our Shopper Audience) personas? 
This feature targets Flipkart audience effectively via defined personas such as gadget freaks, travelers etc. This allows brands to target these audiences not just on the Flipkart app but also on other mobile apps through OSA retargeting.
</p>
<p>
What are the targeting options available? 
Based on the inventory we have different targeting options. The current targeting is done on the basis of gender and geography.
</p>
<p>
How does reporting work for Ad campaigns? 
Post completion of a campaign on our website, our sales representative will be sharing the final report. This report will contain the results, execution and engagement of the completed campaign.
</p>
</div>
<br><br>
<footer>
        <div class="row">
            <div class="col-md-6">
                <center>
                    <p><b>SPORTS EMPORIUM</b></p>
                <a href="IINDEX.php">Home </a>
                <a href="terms.php">| Terms </a>
                <a href="about.php">| About </a>
                <a href="faq.php">| FAQ </a><br>
                <a href="facebook.com"><img src="img/fb.png"></a>
                <a href="twitter.com"><img src="img/tw.png"></a>
                </center>
            </div>
            <div class="col-md-3">
                <ul style="list-style-type:none">
                    <li><span class="glyphicon glyphicon-map-marker"></span> Vidyavihar, Mumbai-070</li>
                    <li><span class="glyphicon glyphicon-phone-alt"></span> +91 98 5645 3456</li>
                    <li><span class="glyphicon glyphicon-envelope"></span> mail@support_sportsemporium.com</li>
                </ul>
            </div>
   
    </div>
        <div class="row">
            <center><p><b>Copyright &copy;2017 Sports Emporium. All Rights Reserved</b></p></center>  
        </div>
    </footer>
</body>
</html>

