<?php
   
    $conn = mysqli_connect("localhost", "root", "", "sports");
   
    if(mysqli_connect_errno()){
        echo "Failed to connect: " . mysqli_connect_error();
    }
 
    error_reporting(0);
 
    $output = '';
?>
<html>
<head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="text/javascript"> 
         function equalHeight(group) {    
    tallest = 0;    
    group.each(function() {       
        thisHeight = $(this).height();       
        if(thisHeight > tallest) {          
            tallest = thisHeight;       
        }    
    });    
    group.each(function() { $(this).height(tallest); });
} 

$(document).ready(function() {   
    equalHeight($(".thumbnail")); 
});
$(function(){
  $("#header").load("header.php"); 
  $("#footer").load("footer.php"); 
});
    </script>`
</head>
<body style="background-color: teal;">
   <div id="header"></div>
   <br><br>

<?php
   
    if(isset($_GET['q']) && $_GET['q'] !== ' '){
        $searchq = $_GET['q'];
       
        $q = mysqli_query($conn, "SELECT * FROM football WHERE brand LIKE '%$searchq%' or type LIKE '%$searchq%' OR name LIKE '%$searchq%';") or die(mysqli_error());
        $r = mysqli_query($conn, "SELECT * FROM cricket WHERE brand LIKE '%$searchq%' or type LIKE '%$searchq%' OR name LIKE '%$searchq%';") or die(mysqli_error());
        $st = mysqli_query($conn, "SELECT * FROM fitness WHERE brand LIKE '%$searchq%' or type LIKE '%$searchq%' OR name LIKE '%$searchq%';") or die(mysqli_error());
        $tu = mysqli_query($conn, "SELECT * FROM badminton WHERE brand LIKE '%$searchq%' or type LIKE '%$searchq%' OR name LIKE '%$searchq%';") or die(mysqli_error());
        
        $c = mysqli_num_rows($q);
        $c1 = mysqli_num_rows($r);
        $c2 = mysqli_num_rows($st);
        $c3 = mysqli_num_rows($tu);
        if($c==0 && $c1 == 0  && $c2==0 && $c3==0)
        {
            $output = 'No search results for <b>"' . $searchq . '"</b>';
        } 
        else { ?>
        <div class="container">
        <div class="row text-center">              
        <?php
            while($row = mysqli_fetch_array($q)){
        ?>
            <div class="col-md-3 col-sm-6">   
                <a href="" ><div class="thumbnail">
                            <img src="<?php echo $row['image'];?>" alt="Adidas Football" style="border-width: 10px; width: 200px; height:200px ">
                            <div class="caption">
                                <h3><?php echo $row['brand']." ".$row['name'];?></h3>
                                <p>Price: Rs.<?php echo $row['newprice'];?> <del><?php echo $row['oldprice'];?></del></p>
                            </div>
                        </div>
                    </a>
            </div>
        <?php        
            }
        ?>
        <?php
            while($row = mysqli_fetch_array($q)){
        ?>
            <div class="col-md-3 col-sm-6">   
                <a href="" ><div class="thumbnail">
                            <img src="<?php echo $row['image'];?>" alt="Adidas Football" style="border-width: 10px; width: 200px; height:200px ">
                            <div class="caption">
                                <h3><?php echo $row['brand']." ".$row['name'];?></h3>
                                <p>Price: Rs.<?php echo $row['newprice'];?> <del><?php echo $row['oldprice'];?></del></p>
                            </div>
                        </div>
                    </a>
            </div>
        <?php        
            }
        ?>
        <?php
            while($row = mysqli_fetch_array($st)){
        ?>
            <div class="col-md-3 col-sm-6">   
                <a href="" ><div class="thumbnail">
                            <img src="<?php echo $row['image'];?>" alt="Adidas Football" style="border-width: 10px; width: 200px; height:200px ">
                            <div class="caption">
                                <h3><?php echo $row['brand']." ".$row['name'];?></h3>
                                <p>Price: Rs.<?php echo $row['newprice'];?> <del><?php echo $row['oldprice'];?></del></p>
                            </div>
                        </div>
                    </a>
            </div>
        <?php        
            }
        ?>
        <?php
            while($row = mysqli_fetch_array($tu)){
        ?>
            <div class="col-md-3 col-sm-6">   
                <a href="" ><div class="thumbnail">
                            <img src="<?php echo $row['image'];?>" alt="Adidas Football" style="border-width: 10px; width: 200px; height:200px ">
                            <div class="caption">
                                <h3><?php echo $row['brand']." ".$row['name'];?></h3>
                                <p>Price: Rs.<?php echo $row['newprice'];?> <del><?php echo $row['oldprice'];?></del></p>
                            </div>
                        </div>
                    </a>
            </div>
        <?php        
            }
        ?>
        </div>
        </div>
            
        <?php   
        }
    } else {
        header("location: ./");
    }
   
    mysqli_close($conn);
 
?>
<div id="footer"></div>
</body>
</html>