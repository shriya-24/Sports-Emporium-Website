<?php
   
    $con = mysqli_connect("localhost", "root", "", "sports");
    session_start();
    if(mysqli_connect_errno()){
        echo "Failed to connect: " . mysqli_connect_error();
    }
   
	$name = $_POST['name'];
	$phone = $_POST['phone'];
	$address = $_POST['address'];	
	$landmark = $_POST['landmark'];
	$id=$_SESSION['user_id'];
	//echo $name,$phone,$id;

$select1_query = "SELECT * FROM cart where cust_id='$id'";
$select1_result = mysqli_query($con, $select1_query) or die(mysqli_error($con));


while($row = mysqli_fetch_array($select1_result))
        {
                $id1 = $row['cust_id'];
                $name1 = $row['name'];
                $quantity1 = $row['quantity'];
                $price1 = $row['quantity']*$row['price'];
               //echo $id1;
               //echo $name1;
                $date1=date("Y-m-d"); 
                $pprice=$row['price'];
                

/*
if(mysqli_num_rows($select1_result)>0)
{
    echo "Order already Exists";
}
else{
*/
$cus_record_insertion_query = "insert into order_details(cid,FullName,Phone,Address,Landmark,prod_name,prod_price,quantity,price,order_date) values ('$id1','$name','$phone','$address','$landmark','$name1','$pprice','$quantity1','$price1','$date1')";
$cus_record_insertion_submit = mysqli_query($con, $cus_record_insertion_query) or die(mysqli_error($con));


}
$select2_query = "SELECT * FROM cart where cust_id='$id'";
$select2_result = mysqli_query($con, $select1_query) or die(mysqli_error($con));
while($row = mysqli_fetch_array($select2_result))
        {
		$id2 = $row['id'];
		$delete_query= "delete from cart where id='$id2'";
		$delete_result = mysqli_query($con, $delete_query) or die(mysqli_error($con));
	}
/*}
mysqli_close($conn);*/
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Order Confirmation</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="text/javascript"> 
	$(function(){
  $("#header").load("header.php"); 
  $("#footer").load("footer.php"); 
});
    </script>
    </head>
</head>
<body style="background-color: teal;">
 <div id="header"></div>
 <h1 style="margin-left:480px; margin-top: 180px; color:wheat;"> Order Successfully Placed!!!</h1>
<br>
<form action="IINDEX.php">
<input style="margin-left: 600px;" type="submit" name="home" value="Continue Shopping"/>
</form>
<div id="footer"></div>
</body>
</html>
