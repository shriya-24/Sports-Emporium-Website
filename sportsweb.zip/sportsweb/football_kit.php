<?php
$con = mysqli_connect("localhost", "root", "", "sports")or die($mysqli_error($con));
$select_query = "SELECT  * FROM football WHERE type='kit'";
$select_query_result = mysqli_query($con, $select_query) or die(mysqli_error($con));
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Football Kit</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="text/javascript"> 
         function equalHeight(group) {    
        tallest = 0;    
    group.each(function() {       
        thisHeight = $(this).height();       
        if(thisHeight > tallest) {          
            tallest = thisHeight;       
        }    
    });    
    group.each(function() { $(this).height(tallest); });
} 

$(document).ready(function() {   
    equalHeight($(".thumbnail")); 
});
$(function(){
  $("#header").load("header.php"); 
  $("#footer").load("footer.php"); 
});
    </script>
    </head>
</head>
<body style="background-color: teal;">
 <div id="header"></div>

    <div class="container">
        <br><br>
       
        <div class="row text-center">
             <?php while ($row = mysqli_fetch_array($select_query_result)) { ?>
            <div class="col-md-3 col-sm-6">
                <a href="" ><div class="thumbnail">
                          <?php if($row['stock']!=0)
                          { ?>
                            <img src="<?php echo $row['image'];?>" alt="Image" style="border-width: 10px; width: 200px; height:200px ">
                          <?php }
                          else { ?>
                            <img src="<?php echo $row['image'];?>" alt="Image" style="filter:blur(5px);  border-width: 10px; width: 200px; height:200px ">
                            <div style="color: white; position: absolute; top: 25%; left: 50%; transform: translate(-50%, -50%);"><b>Out of Stock</b></div>
                          <?php }
                          ?>
                            <div class="caption">
				<form method="post" action="<?php echo $row['description'];?>">  
                                <h3><?php echo $row['brand']." ".$row['name'];?></h3>
                                <p>Price: Rs.<?php echo $row['newprice'];?> <del><?php echo $row['oldprice'];?></del></p>
				<input type="hidden" name="id" value="<?php echo $row["id"]; ?>" />
				<input type="submit" value="More">
				</form>
                            </div>
                        </div>
                    </a>
            </div>
          
        <?php } ?>
    </div>
</div>
<br>
<?php

if(isset($_SESSION['user_id']))
{            if($_SESSION['user_id']==1000)
            {
                ?>
                <form method="POST" style="margin-left:100px;">
                    <input type ="text" name="add" placeholder="Add product">
                     <input type="submit" name="addp" value="Add product"><br><br>
                   <?php
                   if(isset($_POST['addp']))
                   {
                    $s1=$_POST['add'];
                    $query1=mysqli_query($con,"Select id from football where name='$s1';") or die(mysqli_error($con));
                    $c1 = mysqli_num_rows($query1);
                    
                    if($c1!=0)
                    {
                        echo"<script type='text/javascript'>alert('product already exists');</script>";
                    }
                    else
                    {
                        echo "<script language='javascript' type='text/javascript'> location.href='addpro.php' </script>";
                    }
            	 }
                        ?> 
                   
                    
                    <input type="text" name="remove" placeholder="Remove product">
                     <input type="submit" name="remp" value="Remove Product"><br><br>
                    <?php
                    if(isset($_POST['remp']))
                   {
                    $s2=$_POST['remove'];
                    $query2=mysqli_query($con,"Select id from football where name='$s2';") or die(mysqli_error($con));
                    $c2 = mysqli_num_rows($query2);
                    if($c2!=0)
                    {
                        $remove_query = "delete from football where name='$s2'";
                        $remove_submit = mysqli_query($con, $remove_query) or die(mysqli_error($con));
                        echo "<script language='javascript' type='text/javascript'> location.href='football_kit.php' </script>";
                    }
                    else
                    {
                        echo"<script type='text/javascript'>alert('No such product exists');</script>";
                    
                    
                    }
                    
                    }
                    ?>
                    <input type="text" name="inc_prod" placeholder="Type name of the product">
                    <input type="text" name="incr" placeholder="Increase quantity">
                    <input type="submit" name="incp" value="Done"><br><br>
                     <?php
                     if(isset($_POST['incp']))
                   {
                    $s3=$_POST['inc_prod'];
                    $query3=mysqli_query($con,"Select id from football where name='$s3';") or die(mysqli_error($con));
                    $c3 = mysqli_num_rows($query3);
                    if($c3==0)
                    {
                        echo"<script type='text/javascript'>alert('No such product exists');</script>";
                    }
                    else
                    {
                    ?>
                    
                    
                     <?php
                    $increment=$_POST['incr'];
                     $update_query="Update football set stock=stock+$increment where name='$s3'";
                        $update_result=mysqli_query($con, $update_query) or die(mysqli_error($con));
                        echo "<script language='javascript' type='text/javascript'> location.href='football_kit.php' </script>";
                        
                    }
                   }
                    ?>
                    <input type="text" name="decr_prod" placeholder="Type name of the product">
                    <input type="text" name="decr" placeholder="Decrease quantity">
                    <input type="submit" name="decp" value="Done">
                     <?php 
                     if(isset($_POST['decp']))
                   {
                    $s4=$_POST['decr_prod'];
                    $query4=mysqli_query($con,"Select id from football where name='$s4';") or die(mysqli_error($con));
                    $c4 = mysqli_num_rows($query4);
                    if($c4==0)
                    {
                        echo"<script type='text/javascript'>alert('No such product exists');</script>";
                    }
                    else
                    {
                    ?>
                    <?php
                    $decrement=$_POST['decr'];
                    $update_query1="Update football set stock=stock-$decrement where name='$s4'";
                    $update_result1=mysqli_query($con, $update_query1) or die(mysqli_error($con));
                    echo "<script language='javascript' type='text/javascript'> location.href='football_kit.php' </script>";
                    }
                   ?>
                    
                </form>
             <?php   
            }
}}
            ?>
<div id="footer"></div>
</body>
</html>


